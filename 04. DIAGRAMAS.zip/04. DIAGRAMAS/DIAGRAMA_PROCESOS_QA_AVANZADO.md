# DIAGRAMA DE PROCESOS QA AVANZADO CON VARIANTES Y DECISIONES

```mermaid
graph TD
    A[🚀 Inicio del Proyecto QA] --> B[📋 Análisis de Requerimientos]
    B --> C{🔍 Tipo de Proyecto}
    
    C -->|Nuevo Proyecto| D[📝 Creación de Estrategia QA]
    C -->|Proyecto Existente| E[📊 Análisis de Métricas Históricas]
    C -->|Mantenimiento| F[🔧 Actualización de Casos Existentes]
    
    D --> G[🎯 Definición de Criterios de Aceptación]
    E --> G
    F --> G
    
    G --> H[👥 Asignación de Equipo QA]
    H --> I{🏗️ Arquitectura del Sistema}
    
    I -->|Monolítica| J[📱 Pruebas Integradas]
    I -->|Microservicios| K[🔗 Pruebas de Integración Complejas]
    I -->|Híbrida| L[⚖️ Estrategia Mixta]
    
    J --> M[📋 Diseño de Casos de Prueba]
    K --> M
    L --> M
    
    M --> N{🎨 Tipo de Interfaz}
    N -->|Web| O[🌐 Pruebas de Compatibilidad Web]
    N -->|Móvil| P[📱 Pruebas de Dispositivos Móviles]
    N -->|API| Q[🔌 Pruebas de Servicios]
    N -->|Desktop| R[💻 Pruebas de Aplicación Desktop]
    
    O --> S[⚙️ Configuración de Entornos]
    P --> S
    Q --> S
    R --> S
    
    S --> T{🌍 Entorno de Pruebas}
    T -->|DEV| U[🔧 Desarrollo y Unit Testing]
    T -->|QA| V[🧪 Pruebas Funcionales y Regresión]
    T -->|UAT| W[👤 Pruebas de Aceptación de Usuario]
    T -->|PRE| X[🚀 Pruebas de Preproducción]
    
    U --> Y[▶️ Ejecución de Pruebas]
    V --> Y
    W --> Y
    X --> Y
    
    Y --> Z{📊 Resultado de Ejecución}
    Z -->|✅ Pass| AA[📈 Registro de Éxito]
    Z -->|❌ Fail| BB[🐛 Creación de Bug]
    Z -->|⏸️ Blocked| CC[🚫 Registro de Bloqueo]
    Z -->|⚠️ Inconclusive| DD[❓ Investigación Adicional]
    
    BB --> EE{🔍 Severidad del Bug}
    EE -->|Crítica| FF[🚨 Escalamiento Inmediato]
    EE -->|Alta| GG[⚡ Asignación Prioritaria]
    EE -->|Media| HH[📅 Asignación Normal]
    EE -->|Baja| II[⏳ Cola de Baja Prioridad]
    
    FF --> JJ[👨‍💻 Asignación a Desarrollador Senior]
    GG --> KK[👨‍💻 Asignación a Desarrollador]
    HH --> KK
    II --> LL[👨‍💻 Asignación a Desarrollador Junior]
    
    JJ --> MM[🔧 Corrección del Defecto]
    KK --> MM
    LL --> MM
    
    MM --> NN{🔄 Estado de Corrección}
    NN -->|✅ Corregido| OO[🧪 Pruebas DEV]
    NN -->|❌ No Corregido| PP[🔄 Reasignación]
    NN -->|⏳ En Progreso| QQ[⏱️ Seguimiento]
    
    PP --> MM
    QQ --> NN
    
    OO --> RR{🧪 Resultado Pruebas DEV}
    RR -->|✅ Exitoso| SS[🧪 Pruebas QA]
    RR -->|❌ Fallido| TT[🔄 Regreso a Desarrollo]
    
    TT --> MM
    SS --> UU{🧪 Resultado Pruebas QA}
    UU -->|✅ Validado| VV[✅ Cierre del Bug]
    UU -->|❌ No Validado| WW[🔄 Regreso a Desarrollo]
    
    WW --> MM
    VV --> XX[📊 Actualización de Métricas]
    
    CC --> YY{🚫 Tipo de Bloqueo}
    YY -->|Ambiente| ZZ[🔧 Configuración de Entorno]
    YY -->|Datos| AAA[📊 Preparación de Datos]
    YY -->|Dependencias| BBB[🔗 Resolución de Dependencias]
    YY -->|Recursos| CCC[👥 Asignación de Recursos]
    
    ZZ --> DDD[🔄 Reintento de Ejecución]
    AAA --> DDD
    BBB --> DDD
    CCC --> DDD
    
    DDD --> Y
    
    DD --> EEE{❓ Tipo de Investigación}
    EEE -->|Ambiente| FFF[🔍 Diagnóstico de Entorno]
    EEE -->|Datos| GGG[📊 Análisis de Datos]
    EEE -->|Configuración| HHH[⚙️ Revisión de Configuración]
    EEE -->|Código| III[👨‍💻 Revisión de Código]
    
    FFF --> JJJ[📝 Documentación de Hallazgos]
    GGG --> JJJ
    HHH --> JJJ
    III --> JJJ
    
    JJJ --> KKK{📋 Decisión Post Investigación}
    KKK -->|Crear Bug| BB
    KKK -->|Crear Bloqueo| CC
    KKK -->|Reintentar| DDD
    KKK -->|Cerrar Caso| LLL[📝 Documentación de Cierre]
    
    AA --> XX
    LLL --> XX
    
    XX --> MMM{📈 Estado del Proyecto}
    MMM -->|Continuar| NNN[🔄 Siguiente Iteración]
    MMM -->|Completar| OOO[✅ Cierre de Proyecto]
    MMM -->|Escalar| PPP[🚨 Escalamiento a Management]
    
    NNN --> Y
    OOO --> QQQ[📊 Reporte Final]
    PPP --> RRR[👥 Reunión de Escalamiento]
    
    RRR --> SSS{🎯 Decisión de Management}
    SSS -->|Continuar| NNN
    SSS -->|Pausar| TTT[⏸️ Pausa del Proyecto]
    SSS -->|Cancelar| UUU[❌ Cancelación del Proyecto]
    
    QQQ --> VVV[📋 Documentación de Lecciones Aprendidas]
    TTT --> WWW[📝 Documentación de Estado]
    UUU --> XXX[📋 Documentación de Cancelación]
    
    VVV --> YYY[🏁 Fin del Proceso]
    WWW --> YYY
    XXX --> YYY
    
    %% Estilos para diferentes tipos de nodos
    style A fill:#e1f5fe,stroke:#01579b,stroke-width:3px
    style YYY fill:#c8e6c9,stroke:#2e7d32,stroke-width:3px
    style BB fill:#ffcdd2,stroke:#c62828,stroke-width:2px
    style VV fill:#c8e6c9,stroke:#2e7d32,stroke-width:2px
    style CC fill:#fff3e0,stroke:#ef6c00,stroke-width:2px
    style DD fill:#f3e5f5,stroke:#7b1fa2,stroke-width:2px
    style FF fill:#ffebee,stroke:#d32f2f,stroke-width:3px
    style OOO fill:#e8f5e8,stroke:#388e3c,stroke-width:3px
    style PPP fill:#fce4ec,stroke:#ad1457,stroke-width:3px
```
