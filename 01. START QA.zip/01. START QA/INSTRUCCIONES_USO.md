# 📋 Instrucciones de Uso - Sistema QA

## 🚀 Cómo Usar el Sistema

### **Uso Directo (Recomendado)**
1. **Abre `index.html`** en tu navegador
2. **Navega por las secciones** usando el portal principal
3. **Para ver diagramas**: Haz clic en "Visor de Documentos Offline"
4. **Los archivos se abrirán** en tu aplicación predeterminada

### **Con Servidor Local (Opcional - Mejor Experiencia)**

#### **Método 1: Python (Recomendado)**
```bash
# Navega a la carpeta del proyecto
cd "C:\Users\ArturoGomezFuentes\Documents\ARTURO\QA"

# Python 3
python -m http.server 8000

# Python 2
python -m SimpleHTTPServer 8000
```
Luego abre: `http://localhost:8000`

#### **Método 2: Node.js**
```bash
# Instala un servidor simple
npm install -g http-server

# Navega a la carpeta del proyecto
cd "C:\Users\ArturoGomezFuentes\Documents\ARTURO\QA"

# Inicia el servidor
http-server -p 8000
```
Luego abre: `http://localhost:8000`

#### **Método 3: Live Server (VS Code)**
1. Instala la extensión "Live Server" en VS Code
2. Haz clic derecho en `index.html`
3. Selecciona "Open with Live Server"

## 📁 Estructura del Sistema

```
📁 QA/
├── index.html (Portal principal)
├── README.md (Documentación del sistema)
├── 📁 01. START QA/
│   ├── index.html (Portal documentación)
│   ├── visor_offline.html (Visor de documentos)
│   └── INSTRUCCIONES_USO.md (Guía de uso)
├── 📁 02. REGLAMENTACION/
│   ├── 01. QA_REGLAMENTACION.pdf
│   └── 01. QA_REGLAMENTACION.docx
├── 📁 03. TEMPLATES/
│   ├── 01. MATRIZ_DE_PRUEBAS_BTC_RFID_IDAZURE.xlsx
│   ├── 02. FORQA_EVIDENCIA_REQ_DDMMAA.docx
│   └── 03. PROYECTO-DDMMYY_INFORME_DE_CIERRE_DE_PRUEBAS.docx
├── 📁 04. DIAGRAMAS/
│   ├── REGLAMENTACION_QA_DIAGRAMA.md
│   └── 01-15. Diagramas PNG
└── 📁 05. APOYO/
    ├── 01. CTFL - V4.0 - ES - PROGRAMA DE ESTUDIO - V001.01.pdf
    └── 02. AzureTestPlans.pdf
```

## 🎯 Funcionalidades

### **Portal Principal (`index.html`)**
- ✅ Punto de entrada al sistema
- ✅ Navegación a todas las secciones
- ✅ Acceso directo al visor offline

### **Portal de Documentación (`01. START QA/index.html`)**
- ✅ Navegación organizada por secciones
- ✅ Enlaces a todos los documentos
- ✅ Acceso al visor offline

### **Visor Offline (`visor_offline.html`)**
- ✅ Lista todos los documentos disponibles
- ✅ Enlaces directos a archivos
- ✅ Funciona sin servidor web
- ✅ Abre archivos en aplicaciones nativas

## 🔧 Solución de Problemas

### **Error: "No se puede cargar el archivo"**
- **Causa**: Navegador bloquea acceso a archivos locales
- **Solución**: Usa el visor offline o un servidor local

### **Los diagramas no se ven**
- **Causa**: Restricciones de seguridad del navegador
- **Solución**: Usa `visor_offline.html` o un servidor local

### **Archivos no se abren**
- **Causa**: Rutas incorrectas o archivos faltantes
- **Solución**: Verifica que todos los archivos estén en su lugar

## 📱 Compatibilidad

- ✅ **Chrome/Edge**: Funciona perfectamente
- ✅ **Firefox**: Funciona perfectamente
- ✅ **Safari**: Funciona perfectamente
- ✅ **Móviles**: Diseño responsive incluido

## 🎨 Características del Diseño

- ✅ **Diseño Moderno**: Gradientes y animaciones
- ✅ **Responsive**: Funciona en móviles y tablets
- ✅ **Navegación Intuitiva**: Estructura clara
- ✅ **Iconografía**: Iconos descriptivos
- ✅ **Colores Corporativos**: Esquema de colores FORTe Innovation

## 📞 Soporte

Si tienes problemas:
1. Revisa las instrucciones de uso
2. Verifica que todos los archivos estén presentes
3. Prueba con un servidor local
4. Usa el visor offline como alternativa

---
**Sistema QA - FORTe Innovation**  
*Quality Assurance Department*  
*Octubre 2025*
