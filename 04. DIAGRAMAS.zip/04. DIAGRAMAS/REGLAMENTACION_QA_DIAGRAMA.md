# REGLAMENTACIÓN QA - DIAGRAMA DE FLUJO

## Diagrama de Flujo del Proceso QA

```mermaid
graph TD
    A[Inicio del Proyecto] --> B[Definición de Requerimientos]
    B --> C[Creación de User Stories/Epics]
    C --> D[Clasificación Microsoft.RequirementCategory]
    D --> E[Diseño de Casos de Uso]
    E --> F[Creación de Test Cases]
    F --> G[Importación a Azure Test Plans]
    G --> H[Configuración de Test Suites]
    H --> I[Asignación de Responsables QA]
    I --> J[Ejecución de Pruebas]
    
    J --> K{Resultado de Prueba}
    K -->|Pass| L[Registro de Éxito]
    K -->|Fail| M[Creación de Bug]
    K -->|Blocked| N[Registro de Bloqueo]
    
    M --> O[Asignación a Desarrollador]
    O --> P[Corrección del Defecto]
    P --> Q[Pruebas DEV]
    Q --> R[Pruebas QA]
    R --> S{Defecto Corregido?}
    S -->|Sí| T[Cierre del Bug]
    S -->|No| M
    
    L --> U[Actualización de Métricas]
    N --> U
    T --> U
    U --> V[Generación de Reportes]
    V --> W[Validación UAT]
    W --> X[Liberación a Producción]
    
    style A fill:#e1f5fe
    style X fill:#c8e6c9
    style M fill:#ffcdd2
    style T fill:#c8e6c9
```

## Flujo de Estados de Bug

```mermaid
stateDiagram-v2
    [*] --> New
    New --> EnProceso
    EnProceso --> PruebasDEV
    PruebasDEV --> PruebasQA
    PruebasQA --> Cerrado
    PruebasQA --> EnProceso
    PruebasDEV --> EnProceso
    New --> Rechazado
    Cerrado --> [*]
    Rechazado --> [*]
    
    note for New "Bug Reportado"
    note for EnProceso "Asignado a Dev"
    note for PruebasDEV "Corrección Completada"
    note for PruebasQA "Validación DEV OK"
    note for Cerrado "Validación QA OK"
    note for Rechazado "Bug No Válido"
```

## Arquitectura de Herramientas QA

```mermaid
graph LR
    A[Azure DevOps] --> B[Boards]
    A --> C[Test Plans]
    A --> D[Repos]
    A --> E[Pipelines]
    A --> F[Artifacts]
    A --> G[Wiki]
    
    B --> H[Work Items]
    B --> I[Epics Features]
    B --> J[User Stories]
    B --> K[Bugs]
    
    C --> L[Test Cases]
    C --> M[Test Suites]
    C --> N[Test Runs]
    
    D --> O[Scripts QA]
    D --> P[Frameworks]
    
    E --> Q[CI/CD]
    E --> R[Automatización]
    
    F --> S[Dependencias]
    F --> T[Librerías]
    
    G --> U[Documentación]
    G --> V[Métricas]
```

## Tipos de Pruebas y Responsables

```mermaid
graph TD
    A[Tipos de Pruebas] --> B[Smoke Testing]
    A --> C[Sanity Testing]
    A --> D[Funcionales]
    A --> E[Integración]
    A --> F[Regresión Manual]
    A --> G[Regresión Automatizada]
    A --> H[Exploratorias]
    A --> I[Performance Carga]
    A --> J[Seguridad]
    A --> K[UAT]
    A --> L[Compatibilidad]
    A --> M[Recuperación]
    
    B --> N[QA DEV QA]
    C --> O[QA]
    D --> P[QA]
    E --> Q[DEV QA]
    F --> R[QA]
    G --> S[Build CI CD]
    H --> T[QA]
    I --> U[QA UAT]
    J --> V[QA UAT]
    K --> W[UAT]
    L --> X[QA UAT]
    M --> Y[QA Performance]
```

## Flujo de Trazabilidad

```mermaid
graph LR
    A[Epic] --> B[Feature]
    B --> C[User Story Requerimiento]
    C --> D[Caso de Uso]
    C --> E[Test Case]
    C --> F[Task QA]
    E --> G[Bug]
    E --> H[Test Run]
    G --> I[Pipeline]
    H --> I
    I --> J[Azure Boards]
    
    style A fill:#e3f2fd
    style C fill:#fff3e0
    style E fill:#f3e5f5
    style G fill:#ffebee
    style J fill:#e8f5e8
```

## Entornos de Prueba

```mermaid
graph TD
    A[Entornos QA] --> B[DEV]
    A --> C[QA]
    A --> D[UAT]
    A --> E[PROD]
    
    B --> F[Smoke Unit Integración]
    C --> G[Funcionales Regresión Exploratorias]
    D --> H[Performance Carga Seguridad UAT]
    E --> I[Smoke Sanity Verificación Release]
    
    style B fill:#fff3e0
    style C fill:#e8f5e8
    style D fill:#e3f2fd
    style E fill:#ffebee
```

## Ciclo de Vida de Casos de Prueba

```mermaid
graph TD
    A[Diseño Inicial] --> B[Revisión Técnica]
    B --> C[Aprobación Final]
    C --> D[Carga en Azure DevOps]
    D --> E[Ejecución]
    E --> F[Mantenimiento]
    F --> G[Actualización]
    G --> H[Depuración]
    H --> I[Revisión Periódica]
    I --> E
    
    style A fill:#e1f5fe
    style C fill:#c8e6c9
    style E fill:#fff3e0
    style I fill:#f3e5f5
```

## Matriz de Responsabilidades QA

```mermaid
graph LR
    A[QA Manager] --> B[Estrategia QA]
    A --> C[Estandarización]
    A --> D[Revisión Entregables]
    A --> E[Administración Recursos]
    
    F[QA Lead] --> G[Adaptación Estrategia]
    F --> H[Planificación Actividades]
    F --> I[Asignación Tareas]
    F --> J[Consolidación Métricas]
    
    K[QA Analyst] --> L[Diseño Casos]
    K --> M[Ejecución Pruebas]
    K --> N[Documentación]
    K --> O[Registro Defectos]
    
    P[QA Automation] --> Q[Desarrollo Scripts]
    P --> R[Mantenimiento Automatización]
    P --> S[Integración CI CD]
    P --> T[Validación Continua]
    
    U[Performance Tester] --> V[Diseño Pruebas Carga]
    U --> W[Ejecución Rendimiento]
    U --> X[Análisis Resultados]
    U --> Y[Recomendaciones]
```

## Flujo de Ejecución Automatizada

```mermaid
graph TD
    A[Commit/Merge] --> B[Trigger Pipeline]
    B --> C[Build Artefactos]
    C --> D[Inicialización Entorno]
    D --> E[Ejecución Test Suites]
    E --> F[Publicación Resultados]
    F --> G[Generación Reportes]
    G --> H[Almacenamiento Artifacts]
    H --> I[Vincular Work Items]
    I --> J[Notificación Resultados]
    
    style A fill:#e1f5fe
    style E fill:#fff3e0
    style J fill:#c8e6c9
```

## Documentos QA y Entregables

```mermaid
graph TD
    A[Documentos QA] --> B[Plan de Pruebas Master]
    A --> C[Especificación Casos de Prueba]
    A --> D[Registro Ejecución]
    A --> E[Reporte de Defectos]
    A --> F[Matriz de Trazabilidad]
    A --> G[Matriz de Cobertura]
    A --> H[Reporte Resultados QA]
    A --> I[Reporte Cierre Sprint]
    A --> J[Registro Carga Trabajo]
    A --> K[Checklist Entregables]
    A --> L[Plan Automatización]
    A --> M[Plan Control Calidad]
    
    style B fill:#e3f2fd
    style H fill:#fff3e0
    style I fill:#c8e6c9
```

## Flujo de Validación QA en Ciclo DevOps

```mermaid
graph LR
    A[Planificación] --> B[Desarrollo]
    B --> C[Integración Continua]
    C --> D[Pruebas Automatizadas]
    D --> E[Pruebas Manuales]
    E --> F[Validación UAT]
    F --> G[Despliegue]
    G --> H[Validación Post Deploy]
    H --> I[Monitoreo Producción]
    
    D --> J[Smoke Tests]
    D --> K[Regression Tests]
    D --> L[Performance Tests]
    
    E --> M[Functional Tests]
    E --> N[Integration Tests]
    E --> O[Security Tests]
    
    style A fill:#e1f5fe
    style D fill:#fff3e0
    style F fill:#e8f5e8
    style I fill:#c8e6c9
```

## Criterios de Inicio y Cierre

```mermaid
graph TD
    A[Criterios de Inicio] --> B[Caso de Uso con Criterios Aprobados]
    A --> C[Ambiente QA Disponible]
    A --> D[Build Exitoso en Pipeline]
    A --> E[Test Suites Configurados]
    A --> F[Accesos QA Configurados]
    
    G[Criterios de Cierre] --> H[100% Casos Ejecutados]
    G --> I[100% Casos Críticos Aprobados]
    G --> J[Bugs Cerrados/Rechazados]
    G --> K[Reporte Resultados Entregado]
    G --> L[UAT Aprobado]
    
    style B fill:#e8f5e8
    style H fill:#c8e6c9
```

## Gestión de Riesgos QA

```mermaid
graph TD
    A[Riesgos QA] --> B[No Disponibilidad Entorno]
    A --> C[Cambios APIs No Comunicados]
    A --> D[Datos Inconsistentes]
    A --> E[Falta Cobertura Pruebas]
    A --> F[Falta Comunicación QA-Dev]
    
    B --> G[Uso Entorno Espejo]
    C --> H[Validaciones Automáticas]
    D --> I[Versionado Datasets]
    E --> J[Automatización Incremental]
    F --> K[Daily QA-Dev]
    
    style A fill:#ffebee
    style G fill:#c8e6c9
    style H fill:#c8e6c9
    style I fill:#c8e6c9
    style J fill:#c8e6c9
    style K fill:#c8e6c9
```

---

## Ejecución y Evidencias

```mermaid
graph TD
    A[Inicio Ejecución QA] --> B[Selección Test Plan Master]
    B --> C[Configuración Test Suites]
    C --> D[Asignación Responsables]
    D --> E{Tipo de Ejecución}
    
    E -->|Manual| F[Ejecución Manual]
    E -->|Automatizada| G[Pipeline CI/CD]
    
    F --> H[Documentación Resultados]
    G --> I[Ejecución Automatizada]
    I --> J[Publicación Resultados]
    
    H --> K{Resultado de Prueba}
    J --> K
    
    K -->|Pass| L[Registro de Éxito]
    K -->|Fail| M[Creación de Bug]
    K -->|Blocked| N[Registro de Bloqueo]
    
    M --> O[Ciclo de Vida del Bug]
    O --> P[New → En Proceso → Pruebas DEV → Pruebas QA → Cerrado]
    
    L --> Q[Captura de Evidencias]
    N --> Q
    P --> Q
    
    Q --> R[📸 Screenshots]
    Q --> S[🧾 Logs de Consola]
    Q --> T[📑 PDFs]
    Q --> U[🌐 Reportes HTML]
    
    R --> V[Almacenamiento Azure DevOps]
    S --> V
    T --> V
    U --> V
    
    V --> W[Vincular a Test Case]
    V --> X[Vincular a Bug]
    V --> Y[Vincular a Work Item]
    
    W --> Z[Validación por Entorno]
    X --> Z
    Y --> Z
    
    Z --> AA[QA: Funcionales, Integración, API]
    Z --> BB[PRE: Regresión, E2E, Performance]
    Z --> CC[PROD: Sanity Check, Smoke]
    
    AA --> DD[Evidencia Validada]
    BB --> DD
    CC --> DD
    
    DD --> EE[Consolidación de Resultados]
    EE --> FF[Test Summary Report]
    EE --> GG[QA Closure Report]
    EE --> HH[Workload Matrix]
    
    FF --> II[Cierre QA]
    GG --> II
    HH --> II
    
    style A fill:#e1f5fe
    style II fill:#c8e6c9
    style M fill:#ffcdd2
    style O fill:#fff3e0
    style V fill:#f3e5f5
    style DD fill:#e8f5e8
```

## Gestión de Defectos

```mermaid
graph TD
    A[Ejecución de Pruebas] --> B{Resultado}
    B -->|Pass| C[Test Case Exitoso]
    B -->|Fail| D[Creación de Bug]
    
    D --> E[Documentación del Bug]
    E --> F[Campos Obligatorios]
    F --> G[Título, Descripción, Pasos]
    F --> H[Severidad, Prioridad, Ambiente]
    F --> I[Requerimiento Asociado]
    F --> J[Test Case Asociado]
    
    I --> K[Estado: New]
    J --> K
    K --> L[Asignación a Desarrollador]
    L --> M[Estado: En Proceso]
    
    M --> N[Análisis Causa Raíz]
    N --> O[Aplicación de Corrección]
    O --> P[Commit Asociado]
    P --> Q[Estado: Pruebas DEV]
    
    Q --> R[Validación en Desarrollo]
    R --> S{Corrección Exitosa?}
    S -->|No| T[Reabrir Bug]
    S -->|Sí| U[Estado: Pruebas QA]
    
    T --> M
    U --> V[Reejecución Test Cases]
    V --> W{Validación QA}
    W -->|Falló| X[Reabrir Bug]
    W -->|Pasó| Y[Estado: Cerrado]
    
    X --> M
    Y --> Z[Documentación de Cierre]
    Z --> AA[Evidencias y Versión]
    AA --> BB[Reporte Consolidado]
    
    BB --> CC[Métricas QA]
    CC --> DD[Densidad de Defectos]
    CC --> EE[Tasa de Reapertura]
    CC --> FF[MTTR]
    CC --> GG[Defectos Bloqueantes]
    
    style A fill:#e1f5fe
    style D fill:#ffcdd2
    style Y fill:#c8e6c9
    style BB fill:#e8f5e8
    style CC fill:#f3e5f5
```

